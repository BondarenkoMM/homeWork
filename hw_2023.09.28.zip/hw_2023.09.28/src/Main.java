public class Main {
    public static void main(String[] args)
    {
        // 1`st exercise
        char c = 'G';
        int i = 89;
        byte b = 4;
        short s = 56;
        float f = 4.7333436F;
        double d = 4.355453532;
        long l = 12121;
        System.out.println(c);
        System.out.println(i);
        System.out.println(b);
        System.out.println(s);
        System.out.println(f);
        System.out.println(d);
        System.out.println(l);

        // 2`nd exercise
        int num = 175;
        System.out.println(num / 100);
        System.out.println(num / 25);
        System.out.println(num %  10);

        //additional task 1
        short max = 32767;
        max++;
        System.out.println(max);
        // вот тут кстати удивился)

        //task 2
        int firstNum = 123;
        float secondNum = 23.654F;
        System.out.println(firstNum * secondNum);

        //task 3
        char symb = 'A';
        symb++;
        System.out.println(symb);
    }
}