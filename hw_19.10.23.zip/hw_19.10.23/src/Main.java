import java.util.Random;

/* task 1
Напиши программу, которая моделирует ситуацию.
Ты попросил(а) друзей скинуться на подарок на твой День Рождения.
Каждый друг случайным образом может подарить тебе одну купюру номиналом 50, 100, 200 или 500 долларов.
Твоя цель - новенький игровой компьютер, который стоит 10 000 долларов.
Как только друзья подарят тебе нужную сумму (или даже чуть больше),
останавливай сбор подарков и веди всех выпить за твоё здоровье в лучший бар города!
*/
public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();
        int sum = 0;
        for (int i = 0; sum < 10000; i++) {
            int present = 0;
            int randomInt = rnd.nextInt(1, 5);
            present = switch (randomInt){
                case 1 -> 50;
                case 2 -> 100;
                case 3 -> 200;
                default -> 500;
            };
            System.out.printf("Your present is %s$!\n", present);
            sum += present;
        }
        System.out.printf("Guys! Thanks you for presents! With you i collected %s$!\n" +
                "And now we will going to the best bar in the city to celebrate my birthday and new computer!", sum);
    }
}