import java.util.Random;
import java.util.Scanner;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

/*
Напишите программу, моделирующую работу табло при ожидании лифта.
В здании 35 этажей. Лифт находится на произвольном этаже в диапазоне от 0 до 35 (выбирается
случайно). Пользователь нажимает кнопку вызова лифта (вводит на каком этаже он находится).
После этого лифт начинает движение. Пользователь может видеть, как лифт движется по этажам
(программа должна выводить каждый этаж лифта, когда лифт движется).
*/
public class extraTask {
    public static void main(String[] args) throws InterruptedException {
        int floor = new Random().nextInt(36);
        int i = 1;

        System.out.println("To call elevator enter your floor.");
        int currentFloor = new Scanner(System.in).nextInt();
        System.out.printf("Elevator is on the %s floor.\n", floor);
        do {
            if (floor > currentFloor) {
                System.out.println(floor-- + "↓");
                TimeUnit.SECONDS.sleep(2);
                if (floor == currentFloor) System.out.println("*the doors opens*");
            }
            else {
                System.out.println(floor++ + "↑");
                TimeUnit.SECONDS.sleep(2);
                if (floor == currentFloor) System.out.println("*the doors opens*");
            }
        } while (floor != currentFloor);
    }
}
