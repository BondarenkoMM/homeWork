import java.util.Scanner;
/*
Необходимо суммировать все нечётные целые числа в диапазоне,
введённом пользователем. Программу повторять, пока пользователь не введёт «quit».
*/
public class task2 {
    public static void main(String[] args) {
        int sum = 0;
        String cont = "";
        do {
            System.out.println("Enter range(number), and I`ll give you sum of all odd numbers in this range.");
            int userRange = new Scanner(System.in).nextInt();
            for (int i = 1; i < userRange; i += 2) {
                int userSum = i;
                sum += userSum;
            }
            System.out.println(sum);
            System.out.println("Do you want to try again?(YES/QUIT)");
            cont = new Scanner(System.in).nextLine().toUpperCase();
        } while (!cont.equals("QUIT"));
    }
}