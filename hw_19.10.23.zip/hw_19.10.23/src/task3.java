import java.time.DayOfWeek;
import java.util.Arrays;
import java.util.Scanner;

/*
Используйте foreach.
Дан Enum дней недели. Пользователь вводит имя текущего дня в консоль. Программа должна вывести все дни недели, кроме данного.
*/
public class task3 {
    public static void main(String[] args) {
        for (java.time.DayOfWeek day: java.time.DayOfWeek.values()) {
            System.out.println("Enter day of week: ");
            day = DayOfWeek.valueOf(new Scanner(System.in).nextLine().toUpperCase());
            DayOfWeek monday = DayOfWeek.MONDAY;
            DayOfWeek tuesday = DayOfWeek.TUESDAY;
            DayOfWeek wednesday = DayOfWeek.WEDNESDAY;
            DayOfWeek thursday = DayOfWeek.THURSDAY;
            DayOfWeek friday = DayOfWeek.FRIDAY;
            DayOfWeek saturday = DayOfWeek.SATURDAY;
            DayOfWeek sunday = DayOfWeek.SUNDAY;
            switch (day){
                case MONDAY -> System.out.println(tuesday + " " + wednesday + " " + thursday + " " + friday + " " + saturday + " " + sunday);
                case TUESDAY -> System.out.println(monday + " " + wednesday + " " + thursday + " " + friday + " " + saturday + " " + sunday);
                case WEDNESDAY -> System.out.println(monday + " " + tuesday + " " + thursday + " " + friday + " " + saturday + " " + sunday);
                case THURSDAY -> System.out.println(monday + " " + tuesday + " " + wednesday + " " + friday + " " + saturday + " " + sunday);
                case FRIDAY -> System.out.println(monday + " " + tuesday + " " + wednesday + " " + thursday + " " + saturday + " " + sunday);
                case SATURDAY -> System.out.println(monday + " " + tuesday + " " + wednesday + " " + thursday + " " + friday + " " + sunday);
                case SUNDAY -> System.out.println(monday + " " + tuesday + " " + wednesday + " " + thursday + " " + friday + " " + saturday);

            }
        }
    }
}
