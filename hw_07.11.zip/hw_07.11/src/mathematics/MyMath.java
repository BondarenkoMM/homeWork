package mathematics;
public class MyMath {

    private MyMath(){}
    public static int addAll(int... o){
        int sum = 0;
        for (int i = 0; i < o.length; i++) {
            sum += o[i];
        }
        return sum;
    }
    public static long minusAll(long num, int... o){
        for (int i = 0; i < o.length; i++) {
            num -= o[i];
        }
        return num;
    }
    public static int multAll(int... o) {
        int sum = 1;
        for (int i = 0; i < o.length; i++) {
            sum *= o[i];
        }
        return sum;
    }
    public static long powAll(long num, int... o){
        for (int i = 0; i < o.length; i++) {
            for (int j = 0; j < o[i] - 1; j++) {
                num *= num;
            }
        }
        return num;
    }
}
/*Создайте утилитарный класс, который будет аналогом класса Math.
В нём будет один приватный конструктор, а также только статические методы:
addAll - сложение неограниченного числа аргументов
minusAll – принимает исходное число и неограниченный набор аргументов, которые нужно вычесть из исходного числа
multAll – перемножает все данные аргументы
powAll – принимает исходное число-основание и неограниченный набор аргументов степеней.
Нужно последовательно возвести основание во все степени.
Используйте все методы в коде метода main.*/