package machine;

public enum InteriorType {
    LEATHER,
    LEATHERETTE,
    FABRIC,
    ALCANTARA
}
