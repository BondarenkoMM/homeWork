package machine;

public enum UsingSubstance {
    GAS,
    ELECTRICITY,
    PETROL
}
