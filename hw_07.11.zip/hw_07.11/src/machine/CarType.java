package machine;

public enum CarType {
    SEDAN,
    MINIVAN,
    SUV,
    HATCHBACK,
    CABRIOLET,
    SPORT,
    PICKUP,
    MICRO,
    VAN,

}
