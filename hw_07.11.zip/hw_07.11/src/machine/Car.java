package machine;

public class Car {
    String brand;
    String model;
    CarType carType;
    InteriorType interiorType;
    UsingSubstance substance;
    int enginePower;

    public Car(String brand, String model, CarType carType, InteriorType interiorType, UsingSubstance substance, int enginePower) {
        this.brand = brand;
        this.model = model;
        this.carType = carType;
        this.interiorType = interiorType;
        this.substance = substance;
        this.enginePower = enginePower;
    }

    @Override
    public String toString() {
        return "Car information: This is " + brand + " " + model  +
                ", type of this car is " + carType + " with " + interiorType + " interior. "
                + brand + " " + model + " use " + substance +
                " and has " + enginePower + " horsepower.";
    }
}
/*Напишите класс Автомобиль с минимум пятью полями. Переопределите метод toString,
чтобы он выводил полное описание автомобиля по его полям. В программе создайте 3 разных
автомобиля и выведите каждый из них в консоль.
Создайте массив из этих автомобилей. С помощью Arrays.toString() превратите массив в строку и выведите в консоль.
Перейдите в код метода Arrays.toString() и посмотрите на его реализацию. В какой момент автомобиль становится
строкой внутри этого метода?*/