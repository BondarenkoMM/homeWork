import machine.Car;
import machine.CarType;
import machine.InteriorType;
import machine.UsingSubstance;
import mathematics.MyMath;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] a = {3, 2, 2};
        System.out.println("plus " + MyMath.addAll(a));
        long num = 2;
        System.out.println("minus " + MyMath.minusAll(num, a));
        System.out.println("mult " + MyMath.multAll(a));
        System.out.println("pow " + MyMath.powAll(num, a) + "\n");

        Car firstCar = new Car("Toyota", "Supra", CarType.SPORT, InteriorType.LEATHERETTE, UsingSubstance.PETROL, 387);
        Car secondCar = new Car("BMW", "M6", CarType.SEDAN, InteriorType.ALCANTARA, UsingSubstance.GAS, 560);
        Car thirdCar = new Car("Tesla", "X90D", CarType.SEDAN, InteriorType.LEATHER, UsingSubstance.ELECTRICITY, 259);
        System.out.println(firstCar);
        System.out.println(secondCar);
        System.out.println(thirdCar);
        Car[] arr = {firstCar, secondCar, thirdCar};
        System.out.println(Arrays.toString(arr));
    }
}