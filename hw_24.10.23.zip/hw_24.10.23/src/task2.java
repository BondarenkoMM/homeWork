import java.util.Scanner;

/*
Используя рекурсию, написать метод вычисления факториала числа n (n!), вводимого с клавиатуры.
*/
public class task2 {
    public static void main(String[] args) {
        System.out.println("Give me a number, and I`ll give you a factorial of this!");
        int n = new Scanner(System.in).nextInt();
        int result = getFact(n);
        System.out.println(result);
    }
    private static int getFact(int n){
        if (n <= 1) {
            return 1;
        }
        else {
            return n * getFact(n - 1);
            //если честно, долго думал и прибег к помощи интернета,
            //18 строку написал сам, но через цикл for и получал StackOverFlow. хотел бы попросить объяснить почему так
        }
    }
}

