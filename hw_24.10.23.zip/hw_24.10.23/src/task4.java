import java.util.Arrays;

/*
Создайте массив из 5 строк. Используя метод length() строк, найдите строку с наибольшей длиной и строкy с наименьшей длиной.
Выведите массив и полученный строки в консоль.
*/
public class task4 {
    public static void main(String[] args) {
        String[] lines = {"_hello_", "_I_", "_am_", "_an_", "_-_alien_-_"};
        System.out.println(Arrays.toString(lines));
        System.out.println("The smallest string in array is: " + (findShort(lines)));
        System.out.println("The longer string in array is: " + (findLong(lines)));
    }
    private static String findShort(String[] strArr){
        String shortest = strArr[0];
        for (int i = 0; i < strArr.length; i++) {
            String currentSize = strArr[i];
            if (currentSize.length() < shortest.length()) {
                shortest = currentSize;
            }
        }
        return shortest;
    }
    private static String findLong(String[] strArr){
        String longer = strArr[0];
        for (int i = 0; i < strArr.length; i++) {
            String currentSize = strArr[i];
            if (currentSize.length() > longer.length()){
                longer = currentSize;
            }
        }
        return longer;
    }
}