import java.util.Arrays;
import java.util.Random;
/*
Создайте массив из 8 случайных целых чисел из интервала [1;50]
Выведите массив в консоль в строку.
Замените каждый элемент с нечетным индексом на ноль.
Снова выведете массив в консоль в отдельной строке.
Отсортируйте массив по возрастанию.
Снова выведете массив в консоль в отдельной строке.
*/
public class task3 {
    public static void main(String[] args) {
        int[] nums = new int[8];
        Random rnd = new Random();
        for (int i = 0; i < nums.length; i++) {
            nums[i] = rnd.nextInt(1,50);
        }
        System.out.println(Arrays.toString(nums));
        for (int i = 0; i < nums.length; i++) {
            if (nums[i] % 2 != 0) {
                nums[i] = 0;
            }
        }
        System.out.println(Arrays.toString(nums));
        Arrays.sort(nums);
        System.out.println(Arrays.toString(nums));
    }
}