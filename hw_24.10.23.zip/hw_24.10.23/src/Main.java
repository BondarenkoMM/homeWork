import java.util.Scanner;
/* task 1
Сделайте перегруженные методы для перемножения 2-х, 3-х и 4-х чисел.
В методе умножения 3-х чисел используйте вызов метода для 2-х чисел.
В методе умножения 4-х чисел – вызов метода для 3-х чисел.
*/
public class Main {
    public static void main(String[] args) {
        System.out.println("Enter two numbers: ");
        Scanner scn = new Scanner(System.in);
        int num1 = scn.nextInt();
        int num2 = scn.nextInt();
        int result = getNumbers(num1, num2);
        System.out.printf("%s * %s = %s\n", num1, num2, result);
        System.out.println("Enter third number: ");
        int num3 = scn.nextInt();
        result = getNumbers(num1, num2, num3);
        System.out.printf("%s * %s = %s\n", getNumbers(num1, num2), num3, result);
        System.out.println("Enter fourth number: ");
        int num4 = scn.nextInt();
        result = getNumbers(num1, num2, num3, num4);
        System.out.printf("%s * %s = %s\n", getNumbers(num1, num2, num3), num4, result);
    }
    private static int getNumbers(int num1, int num2){
        int sum = num1 * num2;
        return sum;
    }
    private static int getNumbers(int num1, int num2, int num3){
        int sum = getNumbers(num1, num2);
        sum = sum * num3;
        return sum;
    }
    private static int getNumbers(int num1, int num2, int num3, int num4){
        int sum = getNumbers(num1, num2, num3);
        sum = sum * num4;
        return sum;
    }
}