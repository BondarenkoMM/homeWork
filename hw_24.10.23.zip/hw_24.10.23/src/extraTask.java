import java.util.Arrays;
import java.util.Random;

/*
Дан массив размера N-1 , содержащий только различные целые числа в диапазоне от 1 до N .
Найдите недостающий элемент.
Пример 1:
Вход:
N = 5
А[] = {1,2,3,5}
Выход: 4
*/
public class extraTask {
    public static void main(String[] args) {
        int[] numbers = new int[0];
        System.out.println(Arrays.toString(getArray(numbers)));
    }
    private static int[] getArray(int[] numbers){
        Random rnd = new Random();
        int arrayRand = rnd.nextInt(9);
        System.out.println(arrayRand);
        numbers = new int[arrayRand - 1];
        for (int i = 0; i < numbers.length; i++) {
            if (numbers[i] != numbers[i + 1]) {
                numbers[i] = rnd.nextInt(arrayRand);
            };
        }
        return numbers;
    }
}
