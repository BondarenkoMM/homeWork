import java.util.Scanner;

public class task4 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter your number: ");
        int num = scn.nextInt();
        System.out.println(num >> 1);

    }
}
