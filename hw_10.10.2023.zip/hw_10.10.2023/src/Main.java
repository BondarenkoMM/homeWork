import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //task 1
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter the length to convert meters into another magnitude: ");
        double m = scn.nextDouble();
        System.out.printf("%s meters in kilometers = %skm\n", m, m / 1000);
        System.out.printf("%s meters in miles = %snm\n", m, m / 1609.344);
        System.out.printf("%s meters in feet = %s'\n", m, m / 0.3048);
        System.out.printf("%s meters in arshins = %sars\n", m, m / 0.7112);

    }
}