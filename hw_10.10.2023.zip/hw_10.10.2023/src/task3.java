public class task3 {
    public static void main(String[] args) {
        boolean isYearFinished = true;
        boolean isGoodWeather = false;
        boolean hasBoughtRaincoats = true;
        boolean isJimFree = false;
        boolean hasKateComeBack = true;

        boolean hasHikeExist = (isYearFinished && isGoodWeather && (isJimFree ^ hasKateComeBack)) || (isYearFinished && hasBoughtRaincoats && (isJimFree ^ hasKateComeBack));
        System.out.println(hasHikeExist);
    }
}
