public class extraTask {
    public static void main(String[] args) {
        int x = 1;
        int y = 2;

        x = (x << 1);
        y = (y >> 1);

        // или если, как у меня в примере, числа будут сильно разные можно через логические операции:

        int a = 35;
        int b = 1250;
        a = a ^ b;
        b = a ^ b;
        a = a ^ b;



        System.out.println(x);
        System.out.println(y);
        System.out.println(a);
        System.out.println(b);
    }
}
