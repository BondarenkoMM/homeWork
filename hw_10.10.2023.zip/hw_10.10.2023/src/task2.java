import java.util.Scanner;

public class task2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter purchases cost: ");
        double purchasesCost = scn.nextDouble();
        System.out.println("Enter customer amount: ");
        double customerAmount = scn.nextDouble();
        System.out.printf("Customer change is: %s", customerAmount - purchasesCost);

    }
}
