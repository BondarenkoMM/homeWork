import java.util.Scanner;
/*Пользователь вводит, сколько лет он состоит в браке. Программа должна
вывести, какая годовщина свадьбы будет у пользователя следующей (бумажная,
ситцевая, чугунная, серебряная и.д.).*/
//task 1
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Tell me how long have you been married, and i told you how calls your next wedding anniversary!");
        int annYear = scn.nextInt();
        String nameOfAnniversary = switch (annYear){
            case 1 -> "Calico (gauze) wedding";
            case 2 -> "Paper wedding";
            case 3 -> "Leather wedding";
            case 4 -> "Linen wedding";
            case 5 -> "Wooden wedding";
            case 6 -> "Cast iron wedding";
            case 7 -> "Copper (Wool) wedding";
            case 8 -> "Tin-plate wedding";
            case 9 -> "Faience (chamomile) wedding";
            case 10 -> "Tin wedding";
            case 11 -> "Steel wedding";
            case 12 -> "Nickel wedding";
            case 13 -> "Lace (lily of the valley) wedding";
            case 14 -> "Agate wedding";
            case 15 -> "Crystal (Glass) wedding";
            default -> "Do you really care about this?)";
        };
        System.out.println(nameOfAnniversary);
    }
}