package game;

public enum Game {
    ROCK,
    SCISSORS,
    PAPER
}
