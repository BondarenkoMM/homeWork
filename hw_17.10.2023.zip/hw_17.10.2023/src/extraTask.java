import year.Month;


//Создайте Enum месяцев года.
//Задана переменная месяца. Программа должна вывести название сезона для данного месяца
//(зима, весна, лето, осень).
public class extraTask {
    public static void main(String[] args) {
        Month season = switch (Month.values()){
            case Month.JANUARY, Month.FEBRUARY, Month.DECEMBER -> Month.valueOf("It`s winter");
            case Month.MART, Month.APRIL, Month.MAY -> Month.valueOf("It`s spring");
            case Month.JUNE, Month.JUL, Month.AUGUST -> Month.valueOf("It`s summer");
            case Month.SEPTEMBER, Month.OCTOBER, Month.NOVEMBER -> Month.valueOf("It`s autumn");
        };
        System.out.println(season);
    }
}
