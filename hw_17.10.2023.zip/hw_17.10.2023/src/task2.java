import game.Game;

import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
import java.util.Scanner;
/*Напишите консольную игру «Камень, ножницы, бумага». Пользователь вводит
свой выбор (в виде строки или числа). Программа случайным образом делает
свой выбор и выводит на экран. Далее программа показывает, кто победитель –
пользователь или программа.*/
public class task2 {
    public static void main(String[] args) {
        int randNum = new Random().nextInt(0, 3);
        String programChose = switch (randNum) { //making random value
            case 0 -> "\uD83E\uDEA8";
            case 1 -> "\u2702\ufe0f";
            default -> "\uD83D\uDCDC";
        };
        System.out.println("Let`s play RPS! Chose rock, paper or scissors!");
        String userChose = new Scanner(System.in).nextLine().toUpperCase();
        userChose = switch (Game.valueOf(userChose)) { // user chose
            case ROCK -> "\uD83E\uDEA8";
            case SCISSORS -> "\u2702\ufe0f";
            case PAPER -> "\uD83D\uDCDC";
        };
        System.out.println("Your chose is: " + userChose);
        System.out.println("FIGHT!!!");
        System.out.println(userChose + " \uD83D\uDCA5 " + programChose);
        System.out.println(
                userChose == programChose ? "Friendship won!" :
                    (userChose == "\uD83E\uDEA8" && programChose == "\u2702\ufe0f")
                            ^ (userChose == "\u2702\ufe0f" && programChose == "\uD83D\uDCDC")
                            ^ (userChose == "\uD83D\uDCDC" && programChose == "\uD83E\uDEA8") ?
                            ("You win!!!" + "\uD83E\uDD73") : ("You lose. " + "\uD83D\uDC80"));
    }
}