package year;

public enum Month {
    JANUARY,
    FEBRUARY,
    MART,
    APRIL,
    MAY,
    JUNE,
    JUL,
    AUGUST,
    SEPTEMBER,
    OCTOBER,
    NOVEMBER,
    DECEMBER
}
