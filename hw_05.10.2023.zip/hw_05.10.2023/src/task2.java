import java.util.Scanner;

public class task2 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Hi! I`m the new program of Maksym, and I need some information about you!");
        System.out.println("Firstly, what is your name?: ");
        String userName = scn.nextLine();
        System.out.printf("Nice to meet you, %s!\nSo, now: how old are you?: ", userName);
        int userAge = scn.nextInt();
        System.out.println("Excellent! Also I need your weight: ");
        int userWeight = scn.nextInt();
        System.out.printf("Dear %s! In your %d years You so dear for us, like a %dkg of gold!", userName, userAge, userWeight);
    }
}
