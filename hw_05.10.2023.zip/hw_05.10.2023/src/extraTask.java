public class extraTask {
    public static void main(String[] args) {
        double a = Math.random();
        double b = Math.random();
        System.out.printf("There is a two random numbers: %s and %s and operations with them use \"Math\" method;\n", a, b);
        System.out.printf("1. Number difference: %s\n", Math.abs(a - b));
        System.out.printf("2. Minimal value : %s\n", Math.min(a, b));
        System.out.printf("3. Maximal value : %s\n", Math.max(a, b));
        System.out.printf("Exponentiation %s to %s * 10: %s\n", a, b, Math.pow(a, b*10));
    }
}
