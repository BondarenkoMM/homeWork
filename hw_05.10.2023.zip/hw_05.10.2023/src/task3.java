import java.util.Scanner;

public class task3 {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter first number: ");
        int x = scn.nextInt();
        System.out.println("Enter second number: ");
        int y = scn.nextInt();
        System.out.printf("There are operations with %s and %s:\n", x, y);
        System.out.printf("1. %s + %s = %s\n", x, y, x + y);
        System.out.printf("1. %s - %s = %s\n", x, y, x - y);
        System.out.printf("1. %s * %s = %s\n", x, y, x * y);
        System.out.printf("1. %s / %s = %s\n", x, y, x / y);

    }
}
