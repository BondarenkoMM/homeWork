import java.util.Random;

public class Main {
    public static void main(String[] args) {
        //1`st task
        Random rnd = new Random();
        byte bt = (byte) rnd.nextInt();
        System.out.println(bt);
        char sym = (char) rnd.nextInt();
        System.out.println(sym);
        int i = rnd.nextInt();
        System.out.println(i);
        short sh = (short) rnd.nextInt();
        System.out.println(sh);
        long lng = rnd.nextLong();
        System.out.println(lng);
        float flt = rnd.nextFloat();
        System.out.println(flt);
        double dbl = rnd.nextDouble();
        System.out.println(dbl);
        boolean tf = rnd.nextBoolean();
        System.out.println(tf);

        String str = String.valueOf((char) rnd.nextInt('a', 'z' + 1))  + (char) rnd.nextInt('a', 'z' + 1)
                + (char) rnd.nextInt('a', 'z' + 1) + (char) rnd.nextInt('a', 'z' + 1);
        System.out.println(str);
    }
}