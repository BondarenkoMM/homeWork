package human;

import java.util.Random;


public class StrongWife {
    private String name;
    private int age;
    private int wifeMood;

    public StrongWife(String name,int age, int wifeMood) {
        this.wifeMood = wifeMood;
        this.name = name;
        this.age = age;
    }
    public StrongWife(String name, int wifeMood) {
        this.wifeMood = wifeMood;
        this.name = name;
    }
    public StrongWife(int wifeMood){
        this.wifeMood = wifeMood;
    }

    public int getWifeMood() {//случайное настроение жены: 0 - плохое, 1 - хорошее.
        int wifeMood = new Random().nextInt(2);
        return wifeMood;
    }

    public void setWifeMood(int wifeMood) {
        this.wifeMood = wifeMood;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Must not be null");
        }
        this.name = name;
    }
}
