package human;

import java.util.Objects;

public class Neighbour {
String name;
public int age;
private String position;
private String accessory;

    public Neighbour(String name, int age, String position, String accessory) {
        this.name = Objects.requireNonNull(name, "Name can`t be null.");
        this.age = age;
        this.position = position;
        this.accessory = Objects.requireNonNull(accessory, "The neighbour can`t have no accessory.");
    }
    public Neighbour(String name, int age, String accessory){
        this.name = name;
        this.age = age;
        this.accessory = accessory;
    }

    public Neighbour(Neighbour original) {//оригинальная версия для клона
        this(original.name, original.age, original.position, original.accessory);
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        if (age < 35){
            throw new IllegalArgumentException("Neighbour age must be more then 35.");
        }
        this.age = age;
    }

    public String getName(){
        return name;
    }
    public void setName(String name){
        if (name == null || name.isEmpty()){
            throw new IllegalArgumentException("Must not be null");
        } this.name = name;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public String getAccessory() {
        return accessory;
    }

    public void setAccessory(String accessory) {
        this.accessory = accessory;
    }
    private static boolean angryNeighbor(){//метод, отыечающий за действие соседа при плохом настроении у жены
        System.out.printf("*takes accessory and start be noise...*\n");
        return true;//(не совсем понимаю почему здесь булеан, но программа вынудила меня сделать так, ибо иначе не работало)
    }
    public boolean getAngryNeighbour(){//возвращаем метод
        angryNeighbor();
        return true;//всё тот же странный для меня булеан, при исходе
    }
}
