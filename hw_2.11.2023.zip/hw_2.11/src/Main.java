import human.Neighbour;
import human.StrongWife;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Neighbour oleg = new Neighbour("Oleg", 38, "On your head", "Perfarator");


        System.out.println("Hmm.. I don`t hear my neighbours for a few days. is Oleg okay?");
        StrongWife nastia = new StrongWife("Anastasiia", 40, 0);
        int wifeMood1 = nastia.getWifeMood();
        if (wifeMood1 == 0){//вызываем реакцию мужа
            System.out.println(oleg.getAngryNeighbour());
            System.out.printf("%s is angry. %s`s accessory today is %s...\n",nastia.getName(),oleg.getName(), oleg.getAccessory());
        } else {
            System.out.printf("%s drinking beer!\n", oleg.getName());
        }

        System.out.println("Let me see what doing Alex?");

        Neighbour sanya = new Neighbour("Aleksaner", 40, "Lough music");

        StrongWife lilya = new StrongWife("Liliia", 0);
        int wifeMood2 = lilya.getWifeMood();
        if (wifeMood2 == 0){//так же вызываем реакцию мужа
            System.out.println(oleg.getAngryNeighbour());
            System.out.printf("%s is angry. %s`s accessory today is %s...\n",lilya.getName(),sanya.getName(), sanya.getAccessory());
        } else {
            if (wifeMood1 == 0){
                System.out.printf("%s drinking beer!\n", sanya.getName());
            } else {
                System.out.printf("%s drinking beer too!\n", sanya.getName());
            }
        }
        if (wifeMood1 == 0  && wifeMood2 == 0){//создаем наши действия в зависимости от ситуации
            System.out.println("Hah... Women...");
        } else if (wifeMood1 == 1  && wifeMood2 == 1) {
            System.out.println("Guys! I`m going to you!");
        } else {
            System.out.println("Can be better:(");
        }
        Neighbour cloned = new Neighbour(sanya);
        System.out.println(cloned == sanya);
        cloned.age = 48;
        System.out.println(cloned.age);
        System.out.println(sanya.age);
    }
    //работа получилась довольно большая и я постарался уделить ей больше времени, но получилось очень интересно) надеюсь вас хотя-бы немного улыюнуло)
    //очень надеюсь что не упустил здесь ничего, ибо предыдущую версию выполнил недоработаной. Обновил, исправил некоторые глупые баги и
    //недоработки ну и сделал попросту код красивее)
    //
    //                      *** Был бы очень рад получить фитбэк именно о этой работе! Спасибо за внимание! ***
}