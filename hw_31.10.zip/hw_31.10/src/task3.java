/*дана строка вида AAAABBBCCCDDEG…, состоящая только из заглавных символов латинского алфавита. Напишите метод,
который «свернёт» строку к виду A4B3C3D2EG, т.е. количество букв записывается цифрой. Если буква одна, то цифра не ставится.*/
public class task3 {
    public static void main(String[] args) {
        String letters = "AAAABBBCCCDDEG";
        System.out.println(getCompressed(letters));
    }
    private static StringBuilder getCompressed(String letters){
        StringBuilder newLetters = new StringBuilder();
        char curSym = letters.charAt(0);
        int count = 0;
        for (int i = 0; i < letters.length(); i++) {
            if (curSym == letters.charAt(i)){
                count++;
            } else {
                newLetters.append(curSym);
                if (count > 1){
                    newLetters.append(count);
                }
                curSym = letters.charAt(i);
                count = 1;
            }
        }
        newLetters.append(curSym);
        if (count > 1){
            newLetters.append(count);
        }
        return newLetters;
    }
}
