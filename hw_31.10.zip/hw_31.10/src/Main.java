import java.util.Scanner;

/*Введите 2 слова, воспользуйтесь сканером, состоящие из четного количества букв (проверьте количество букв в слове).
Нужно получить слово, состоящее из первой половины первого слова и второй половины второго слова. распечатать на консоль.*/
public class Main {
    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Enter two even words:\n1: ");
        String word1 = scn.nextLine();
        System.out.println("2: ");
        String word2 = scn.nextLine();
        System.out.println(splitWords(word1, word2));
    }

    private static String splitWords(String word1, String word2) {
        String result = "";
        if (word1.length() % 2 == 0) {
            if (word2.length() % 2 == 0){
                result = word1.substring(0, word1.length()/2) + word2.substring(word2.length()/2, word2.lastIndexOf(""));
            } else System.out.println("Your 2`nd word is not correct!");
        } else System.out.println("Your 1`st word is not correct!");
        return result;
    }
}