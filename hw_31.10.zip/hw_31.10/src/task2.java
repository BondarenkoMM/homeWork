import java.util.Locale;

/*Создайте строку через new - I study Basic Java!
Напишите метод, который принимает в качестве параметра строку, передайте в этот метод созданную строку

Распечатать последний символ строки. Используем метод String.charAt().

Проверить, содержит ли ваша строка подстроку “Java”. Используем метод String.contains().

Заменить все символы “а” на “о”.

Преобразуйте строку к верхнему регистру.

Преобразуйте строку к нижнему регистру.

Вырезать строку Java c помощью метода String.substring().*/
public class task2 {
    public static void main(String[] args) {
        String str = new String("I study Basic Java!");
        getStrings(str);
    }
    private static void getStrings(String str){
        System.out.println(str.charAt(str.length()-1));
        System.out.println(str.contains("Java"));
        System.out.println(str.replace('a', 'o'));
        System.out.println(str.toUpperCase());
        System.out.println(str.toLowerCase());
        System.out.println(str.substring(str.indexOf("Java")));
    }
}
