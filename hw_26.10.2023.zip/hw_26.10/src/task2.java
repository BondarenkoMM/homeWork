import java.util.Arrays;

//Создайте двумерный массив и заполните его заглавными буквами русского алфавита. Буква Ё должна быть на своём месте.
public class task2 {
    public static void main(String[] args) {
        char[][] symbols = new char[33][1];
        System.out.println(Arrays.deepToString(putSymbols(symbols)));
    }
    private static char[][] putSymbols(char[][] symbols){
        char a = 'А';
        for (int i = 0; i < symbols.length; i++) {
            for (int j = 0; j < symbols[i].length; j++) {
                symbols[i][j] = a;
                if (a == 'Е'){
                    i++;
                    j = 0;
                    symbols[i][j] = 'Ё';
                }
                a++;
            }
        }
        
        return symbols;
    }
}