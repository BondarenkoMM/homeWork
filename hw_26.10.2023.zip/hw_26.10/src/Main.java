import java.time.LocalDate;
import java.util.Arrays;

/*
1 Создайте массив из 8 элементов. В массиве должны храниться даты (класс LocalDate).
Чтобы создать элемент LocalDate используйте метод
LocalDate.of(год, месяц, день), где год, месяц и день – целые числа.
Выведите массив в консоль.
2 Напишите метод, который отсортирует массив дат по году. Выведите массив в консоль.
3 Напишите метод, который отсортирует массив дат по дню месяца. Выведите массив в консоль.
Сортировку можно выполнить по любому из изученных алгоритмов.
*/
public class Main {
    public static void main(String[] args) {
        LocalDate[] dates = {LocalDate.of(2005, 2, 14),
                LocalDate.of(1983, 3, 25),
                LocalDate.of(1986, 1, 10),
                LocalDate.of(2007, 3, 8),
                LocalDate.of(2006, 3, 29),
                LocalDate.of(2005, 2, 6),
                LocalDate.of(2004, 9, 15),
                LocalDate.of(2003, 8, 17)};
        System.out.println(Arrays.toString(dates));
        System.out.println(Arrays.toString(sortByYear(dates)));
        System.out.println(Arrays.toString(sortByDay(dates)));
    }

    private static LocalDate[] sortByYear(LocalDate[] dates) {
        for (int i = 0; i < dates.length; i++) {
            for (int j = 0; j < dates.length; j++) {
                LocalDate date1 = dates[i];
                LocalDate date2 = dates[j];
                if (date1.getYear() > date2.getYear()){
                    LocalDate n = dates[i];
                    dates[i] = dates[j];
                    dates[j] = n;
                }
            }
        }
        return dates;
    }
    private static LocalDate[] sortByDay(LocalDate[] dates) {
        for (int i = 0; i < dates.length; i++) {
            for (int j = 0; j < dates.length; j++) {
                LocalDate date1 = dates[i];
                LocalDate date2 = dates[j];
                if (date1.getDayOfMonth() > date2.getDayOfMonth()){
                    LocalDate n = dates[i];
                    dates[i] = dates[j];
                    dates[j] = n;
                }
            }
        }
        return dates;
    }

}
