import human.Neighbour;
import human.StrongWife;

import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Neighbour oleg = new Neighbour("Oleg", 38, "On your head", "Perfarator");

        int wifeMood1 = new Random().nextInt(2);
        System.out.println("Hmm.. I don`t hear my neighbours for a few days. is Oleg okay?");
        StrongWife nastia = new StrongWife("Anastasiia", 40, wifeMood1);
        if (nastia.getWifeMood() == 1){
            System.out.println(oleg.getAngryNeighbour());
            System.out.printf("%s is angry. %s`s accessory today is %s...\n",nastia.getName(),oleg.getName(), oleg.getAccessory());
        } else {
            System.out.printf("Drinking beer!\n");
        }

        System.out.println("Let me see what doing Alex?");

        Neighbour sanya = new Neighbour("Aleksaner", 40, "Lough music");

        int wifeMood2 = new Random().nextInt(2);
        StrongWife lilya = new StrongWife("Liliia", wifeMood2);
        if (lilya.getWifeMood() == 1){
            System.out.println(oleg.getAngryNeighbour());
            System.out.printf("%s is angry. %s`s accessory today is %s...\n",lilya.getName(),sanya.getName(), sanya.getAccessory());
        } else {
            System.out.println("Drinking beer!");
        }
        if (nastia.getWifeMood() == 0  && lilya.getWifeMood() == 0){
            System.out.println("Hah... Women...");
        } else if (nastia.getWifeMood() == 1  && lilya.getWifeMood() == 1) {
            System.out.println("Guys! I`m going to you!");
        } else {
            System.out.println("Ok");
        }
        Neighbour cloned = new Neighbour(sanya);
        System.out.println(cloned == sanya);
        cloned.age = 48;
        System.out.println(cloned.age);
        System.out.println(sanya.age);
    }
}